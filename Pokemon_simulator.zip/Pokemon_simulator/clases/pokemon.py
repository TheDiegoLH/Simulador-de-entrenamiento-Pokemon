class Pokemon:
    _contador_pokemons = 0  # atributo de clase

    def __init__(self, nombre, ataque, defensa, salud):
        self.nombre = nombre
        self.nivel = 1
        self.ataque = ataque
        self.defensa = defensa
        self.salud = salud
        self.salud_maxima = salud
        self._tipo = None
        Pokemon._contador_pokemons += 1
        print(f"{self.nombre} ha sido capturado! 🐾")

    def __del__(self):
        print(f"{self.nombre} ha sido liberado 🕊")
        Pokemon._contador_pokemons -= 1

    def entrenar(self, stat1=True, stat2=True, stat3=True):
        self.nivel += 1
        if stat1: self.ataque += 2
        if stat2: self.defensa += 2
        if stat3:
            self.salud_maxima += 5
            self.salud = self.salud_maxima
        print(f"{self.nombre} ha subido a nivel {self.nivel}!")

    def atacar(self, objetivo):
        if objetivo.salud <= 0:
            print(f"{objetivo.nombre} está debilitado y no puede ser atacado.")
            return
        daño = max(1, self.ataque - objetivo.defensa)
        objetivo.recibir_dano(daño)
        print(f"{self.nombre} atacó a {objetivo.nombre} causando {daño} de daño.")

    def recibir_dano(self, cantidad):
        self.salud -= cantidad
        if self.salud <= 0:
            self.salud = 0
            print(f"{self.nombre} se ha debilitado ❌")

    def mostrar_info(self):
        print(f"Nombre: {self.nombre} | Tipo: {self._tipo} | Nivel: {self.nivel}")
        print(f"Ataque: {self.ataque} | Defensa: {self.defensa} | Salud: {self.salud}/{self.salud_maxima}")

    @classmethod
    def total_pokemons(cls):
        return cls._contador_pokemons

    @staticmethod
    def validar_estadistica(valor):
        return valor > 0


# 🔥 Clase Fuego
class PokemonFuego(Pokemon):
    def __init__(self, nombre, ataque, defensa, salud):
        super().__init__(nombre, ataque, defensa, salud)
        self._tipo = "Fuego"

    def atacar(self, objetivo):
        daño = max(1, self.ataque - objetivo.defensa)
        if objetivo._tipo == "Planta":
            daño *= 2
        elif objetivo._tipo == "Agua":
            daño //= 2
        objetivo.recibir_dano(daño)
        print(f"{self.nombre} lanzó un ataque de FUEGO contra {objetivo.nombre} causando {daño} de daño.")

    def mostrar_info(self):
        super().mostrar_info()
        print("🔥 ¡Arde con pasión!")


# 💧 Clase Agua
class PokemonAgua(Pokemon):
    def __init__(self, nombre, ataque, defensa, salud):
        super().__init__(nombre, ataque, defensa, salud)
        self._tipo = "Agua"

    def atacar(self, objetivo):
        daño = max(1, self.ataque - objetivo.defensa)
        if objetivo._tipo == "Fuego":
            daño *= 2
        elif objetivo._tipo == "Planta":
            daño //= 2
        objetivo.recibir_dano(daño)
        print(f"{self.nombre} lanzó un ataque de AGUA contra {objetivo.nombre} causando {daño} de daño.")

    def mostrar_info(self):
        super().mostrar_info()
        print("💧 ¡Fluye como el río!")


# 🍃 Clase Planta
class PokemonPlanta(Pokemon):
    def __init__(self, nombre, ataque, defensa, salud):
        super().__init__(nombre, ataque, defensa, salud)
        self._tipo = "Planta"

    def atacar(self, objetivo):
        daño = max(1, self.ataque - objetivo.defensa)
        if objetivo._tipo == "Agua":
            daño *= 2
        elif objetivo._tipo == "Fuego":
            daño //= 2
        objetivo.recibir_dano(daño)
        print(f"{self.nombre} lanzó un ataque de PLANTA contra {objetivo.nombre} causando {daño} de daño.")

    def mostrar_info(self):
        super().mostrar_info()
        print("🍃 ¡Crece con fuerza!")

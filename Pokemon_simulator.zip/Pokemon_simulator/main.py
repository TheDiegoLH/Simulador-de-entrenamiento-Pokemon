from clases.pokemon import PokemonFuego, PokemonAgua, PokemonPlanta, Pokemon

equipo = []

def menu():
    while True:
        print("\n--- MENÚ PRINCIPAL ---")
        print("1. Capturar Pokémon")
        print("2. Entrenar Pokémon")
        print("3. Atacar")
        print("4. Ver información")
        print("5. Total de Pokémon")
        print("6. Liberar Pokémon")
        print("7. Salir")

        opcion = input("Elige una opción: ")

        try:
            if opcion == "1":
                nombre = input("Nombre: ")
                tipo = input("Tipo (Fuego/Agua/Planta): ")
                ataque = int(input("Ataque: "))
                defensa = int(input("Defensa: "))
                salud = int(input("Salud: "))

                if not Pokemon.validar_estadistica(ataque) or not Pokemon.validar_estadistica(defensa) or not Pokemon.validar_estadistica(salud):
                    print("❌ Estadísticas inválidas.")
                    continue

                if tipo == "Fuego":
                    equipo.append(PokemonFuego(nombre, ataque, defensa, salud))
                elif tipo == "Agua":
                    equipo.append(PokemonAgua(nombre, ataque, defensa, salud))
                elif tipo == "Planta":
                    equipo.append(PokemonPlanta(nombre, ataque, defensa, salud))
                else:
                    print("❌ Tipo inválido.")

            elif opcion == "2":
                for i, p in enumerate(equipo):
                    print(f"{i+1}. {p.nombre}")
                idx = int(input("Selecciona Pokémon: ")) - 1
                equipo[idx].entrenar()

            elif opcion == "3":
                for i, p in enumerate(equipo):
                    print(f"{i+1}. {p.nombre}")
                atacante = int(input("Atacante: ")) - 1
                objetivo = int(input("Objetivo: ")) - 1
                equipo[atacante].atacar(equipo[objetivo])

            elif opcion == "4":
                for p in equipo:
                    p.mostrar_info()

            elif opcion == "5":
                print(f"Total de Pokémon: {Pokemon.total_pokemons()}")

            elif opcion == "6":
                for i, p in enumerate(equipo):
                    print(f"{i+1}. {p.nombre}")
                idx = int(input("Selecciona Pokémon a liberar: ")) - 1
                del equipo[idx]

            elif opcion == "7":
                print("👋 ¡Hasta luego, entrenador!")
                break

            else:
                print("❌ Opción inválida.")

        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    menu()
